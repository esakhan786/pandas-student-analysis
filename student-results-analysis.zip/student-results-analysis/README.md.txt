# 📊 Student Results Analysis using Pandas

This project demonstrates basic data analysis using **Python Pandas**.

## 🔹 Features
- Create student DataFrame
- Add new student record
- Calculate total & average marks
- Identify top performer
- Filter students with average > 80
- Sort results by average
- Export final data to CSV

## 🛠️ Technologies Used
- Python
- Pandas

## 📁 Output
- student_results.csv

## 🚀 Author
**Essa Khan**  
BSCS – COMSATS University Abbottabad
